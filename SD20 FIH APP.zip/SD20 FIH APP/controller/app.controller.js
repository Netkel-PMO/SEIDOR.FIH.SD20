sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/util/MockServer",
	'sap/ui/model/odata/v2/ODataModel'
], function(BaseController, JSONModel, MessageToast, MockServer, ODataModel) {
	"use strict";
	return BaseController.extend("gest.adic.cirugia.controller.app", {

		onInit: function() {
			// var oModel, oView;
			// var oMockServer = new MockServer({
			// 	rootUri: "sap/opu/odata/sap/ZODATA_gest.adic.cirugia_SRV/"
			// });
			// this._oMockServer = oMockServer;
			// oMockServer.simulate(
			// 	"localService/metadata.xml",
			// 	"localService/mockdata");
			// oMockServer.start();
			// oModel = new ODataModel("sap/opu/odata/sap/ZODATA_gest.adic.cirugia_SRV", {
			// 	defaultCountMode: "Inline"
			// });
			// oView = this.getView();
			// oView.setModel(oModel);

		},
		onBeforeRendering: function() {
			//	console.log('App_onBeforeRendering');
		}

	});
});