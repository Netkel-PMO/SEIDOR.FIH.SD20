sap.ui.define([
	"./BaseController",
	"sap/ui/core/util/MockServer",
	'sap/ui/model/odata/v2/ODataModel',
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Label",
	"sap/m/library",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/TextArea",
	"sap/ui/core/Core"
], function (BaseController, MockServer, ODataModel, JSONModel, Dialog, Button, Label, mobileLibrary, MessageToast, Text, TextArea,Core) {
	"use strict";
	// shortcut for sap.m.ButtonType
	var ButtonType = mobileLibrary.ButtonType;

	// shortcut for sap.m.DialogType
	var DialogType = mobileLibrary.DialogType;
	return BaseController.extend("gest.adic.cirugia.controller.detallepedido", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gest.adic.cirugia.view.detallepedido
		 */
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("detalle").attachPatternMatched(this._onRouteFound, this);

			this.getView().byId("idmaterial").onsapenter = function (e) {
				this._onValidarMaterial()
				this.getView().byId("idmaterial").setValue("");
			}.bind(this);

		},
		_onRouteFound: function (oEvent) {

		},
		onSort: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Sort");
			}
		},

		onFilter: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}
		},

		onGroup: function () {
			//	MessageToast.show("Not available as this feature is disabled for this app in the view.xml");

			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Group");
			}
		},
		onColumns: function () {
			var oSmartTable = this._getSmartTable();
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Columns");
			}
		},
		_getSmartTable: function () {
			if (!this._oSmartTable) {
				this._oSmartTable = this.getView().byId("LineItemSmartTable");
			}
			return this._oSmartTable;
		},
		// borrar fila carga de Pedidos
		_onTableDelete: function (oEvent) {
			var model = this.getOwnerComponent().getModel("MPedido");
			var spath = oEvent.getSource().oPropagatedProperties.oBindingContexts.MPedido.sPath;
			var index = oEvent.getSource().oPropagatedProperties.oBindingContexts.MPedido.sPath.substr(1, 1);
			var currentRows = model.getProperty("/");

			currentRows.splice(index, 1);

			model.setProperty("/", currentRows);

		},
		// nueva fila carga de Pedidos
		_onTableAdd: function (oEvent) {
			var newRows = {};
			let actualRows;
			let spath;
			var currentRows;
			var model = this.getOwnerComponent().getModel("MPedido");
			currentRows = model.getProperty("/");
			let otable = this.getView().byId("iddetallepedido").getSelectedItems();
			if (otable.length === 1) {
				spath = otable[0].getBindingContextPath();
				actualRows = otable[0].getModel("MPedido").getProperty(spath);

			} else {

				//	currentRows = model.getProperty("/");
				actualRows = currentRows[0];
			}

			//		var oldRows = currentRows.concat(currentRows[0]);

			if (!actualRows) {
				MessageToast.show("No hay Pedido, no se puede agregar nuevo Material");
				return;
			}

			newRows.pedido = actualRows.pedido;
			newRows.material = this.getView().byId("idmaterial").getValue();
			newRows.cantidad = this.getView().byId("idcantidad").getValue();
			newRows.lote = this.getView().byId("idlote").getValue();
			newRows.sala_cirugia = actualRows.sala_cirugia;
			newRows.sala_urgencia = actualRows.sala_urgencia;
			newRows.nombre_paciente = actualRows.nombre_paciente;
			newRows.doc_pacienteId = actualRows.doc_pacienteId;
			newRows.protocolo_cirugia = actualRows.protocolo_cirugia;
			newRows.protocolo_urgencia = actualRows.protocolo_urgencia;
			newRows.descripcion = actualRows.descripcion;
			var oldRows = currentRows.concat(newRows);
			model.setProperty("/", oldRows);
			this.getView().getModel("MPedido").refresh(true);
		},

		_onValidarMaterial: function () {
			this.getView().byId("idmaterial").setBusy(true);

			var la_filtersOr = [];
			var la_filtersAnd = [];
			var lo_paraFilter = [];

			var sMaterial = this.getView().byId("idmaterial").getValue();

			if (sMaterial != "") {
				lo_paraFilter.push(new sap.ui.model.Filter({
					path: "material",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sMaterial
				}));

			}
		 


			la_filtersAnd.push(new sap.ui.model.Filter(lo_paraFilter, true));


			this.getModel().read("/datosMaterialSet", {
				filters: la_filtersAnd,
				success: function (oData, response) {
					this._onMostrarMensaje("msgMaterial");
					this.getView().byId("idmaterial").setBusy(false);
				}.bind(this),
				error: function (error) {
					this._onMostrarMensaje("msgNoMaterial");
					this.getView().byId("idmaterial").setBusy(false);
					// var hdrMessageObject = JSON.parse(error.responseText);
					// MessageToast.show(hdrMessageObject.error.message.value);
				}.bind(this)
			});

			// this.getModel().read("/datosMaterialSet", {
			// 	filters: la_filtersAnd,
			// 	sucess: function (oData, response) {
			// 		this._onMostrarMensaje("msgMaterial");
			// 		this.getView().byId("idmaterial").setBusy(false);
			// 	}.bind(this), // callback function for success
			// 	error: function (oError) {
			// 		this._onMostrarMensaje("msgNoMaterial");
			// 		this.getView().byId("idmaterial").setBusy(false);

			// 	}.bind(this) // callback function for error

			// });
		},

		_onMostrarMensaje: function (text, key) {
			var propiedadesmensjae = {
				duration: 3000, // default
				width: "40em", // default
				my: "center top", // default
				at: "center top", // default
				of: this.getView().byId("idPageDel"), // default
				offset: "0 0", // default
				collision: "fit fit", // default
				onClose: null, // default
				autoClose: false, // default
				animationTimingFunction: "ease-in-out", // default
				animationDuration: 1000, // default
				closeOnBrowserNavigation: false // default
			};

			var mensaje = this.getResourceBundle().getText(text, [key]);
			MessageToast.show(mensaje, propiedadesmensjae);

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf gest.adic.cirugia.view.detallepedido
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf gest.adic.cirugia.view.detallepedido
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf gest.adic.cirugia.view.detallepedido
		 */
		//	onExit: function() {
		//
		//	}

		onEnfermeraDialogPress: function () {
			if (!this.oNombreEnfermeraDialog) {
				this.oNombreEnfermeraDialog = new Dialog({
					type: DialogType.Message,
					title: "Nombre Enfermera",
					content: [
						new Label({
							text: "Ingrese Nombre Enfermera",
							labelFor: "submissionNote"
						}),
						new TextArea("idnombreenfermera", {
							width: "100%",
							placeholder: "Nombre Enfermera (Requerido)",
							liveChange: function (oEvent) {
								var sText = oEvent.getParameter("value");
								this.oNombreEnfermeraDialog.getBeginButton().setEnabled(sText.length > 0);
							}.bind(this)
						})
					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "OK",
						enabled: false,
						press: function () {
							this.sNombreEnfermera = Core.byId("idnombreenfermera").getValue();
							this.onEnviarPedidos();
							this.oNombreEnfermeraDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oNombreEnfermeraDialog.close();
						}.bind(this)
					})
				});
			}

			this.oNombreEnfermeraDialog.open();
		},


		_onEnfermera: function (oEvent) {
			this.onEnfermeraDialogPress();
		//	if (this.sNombreEnfermera != "") {
		//		this.onEnviarPedidos();
	//		}


		},

		onEnviarPedidos: function () {

			let otable = this.getView().byId("iddetallepedido").getSelectedItems();
			let spath;
			let sdata;
			let oModel = this.getView().getModel();
			oModel.setUseBatch(false);

			oModel.setDeferredGroups(["myBatch"]);
			let mParameters = {
				groupId: "myBatch"
			};

			this._onMostrarMensaje("msgProcesarPedido");

			for (var i = 0; i < otable.length; i++) {
				const spath = otable[i].getBindingContextPath();
				const sdata = otable[i].getModel("MPedido").getProperty(spath);
				sdata.nomb_enfermera = this.sNombreEnfermera;
				this.createOmodel(sdata, oModel);
			}
			oModel.submitChanges({

				success: function (oData, response) {
					//		sap.m.MessageBox.success("Success Saving Entries!");
				},
				error: function (oError) {
					//		sap.m.MessageBox.error("Error Saving Entries!!");
				}
			});
			oModel.setUseBatch(true);

		},

		createOmodel: function (oData, oModel) {

			oModel.create("/update_pedidoSet", oData, {

				success: function (odata, response) {

					this.oModeloJson = new JSONModel();
					// response header
					if (response.headers["sap-message"]) {
						var tipoMensaje;
						var hdrMessage = response.headers["sap-message"];
						var hdrMessageObject = JSON.parse(hdrMessage);

						var modelo = [];
						if (hdrMessageObject.details.length >= 1) {
							for (var e = 0; e < hdrMessageObject.details.length; e++) {
								var message = {};
								switch (hdrMessageObject.details[e].severity) {
									case "information":
										tipoMensaje = sap.ui.core.MessageType.Information;
										break;
									case "success":
										tipoMensaje = sap.ui.core.MessageType.Success;
										break;
									case "error":
										tipoMensaje = sap.ui.core.MessageType.Error;
										break;
									default:
								}

								message.type = tipoMensaje;
								message.title = hdrMessageObject.details[e].severity;
								message.description = hdrMessageObject.details[e].message;
								message.subtitle = hdrMessageObject.details[e].message;
								message.counter = 1;

								modelo.push(message);
							}
						} else {
							var message = {};
							switch (hdrMessageObject.severity) {
								case "information":
									tipoMensaje = sap.ui.core.MessageType.Information;
									break;
								case "success":
									tipoMensaje = sap.ui.core.MessageType.Success;
									break;
								case "error":
									tipoMensaje = sap.ui.core.MessageType.Error;
									break;
								default:
							}
							message.type = tipoMensaje;
							message.title = hdrMessageObject.severity;
							message.description = hdrMessageObject.message;
							message.subtitle = this.getView().byId("idmaterial").getValue();
							message.counter = 1;

							modelo.push(message);
						}

						this.oModeloJson.setData(modelo);
						this._onMessajeView(this.oModeloJson);

					}
					//	this._onButtonPressReturn();
				}.bind(this),
				error: function (error) {
					//		this.onShowMessaje(this.getResourceBundle().getText("msgErrorPedido"));
				}.bind(this)
			});

		},
		_onMessajeView: function (oModel) {

			var that = this;

			var oMessageTemplate = new sap.m.MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}',
				counter: '{counter}',
				markupDescription: '{markupDescription}'
			});

			this.oMessageView = new sap.m.MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});

			var oBackButton = new sap.m.Button({
				icon: sap.ui.core.IconPool.getIconURI("nav-back"),
				visible: false,
				press: function () {
					that.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			this.oMessageView.setModel(oModel);

			this.oDialog = new sap.m.Dialog({
				resizable: true,
				content: this.oMessageView,
				state: sap.ui.core.MessageType.Information,
				beginButton: new sap.m.Button({
					press: function () {
						this.getParent().close();
					},
					text: "Cerrar"
				}),
				customHeader: new sap.m.Bar({
					contentMiddle: [
						new sap.m.Text({
							text: "Mensajes"
						})
					],
					contentLeft: [oBackButton]
				}),
				contentHeight: "300px",
				contentWidth: "500px",
				verticalScrolling: false
			});

			this.oMessageView.navigateBack();
			this.oDialog.open();

		},
		_onButtonPressReturn: function (oEvent) {
			var id = "1";
			this.getRouter().navTo("inicio", {
				id
			}, true);
		},
		_onEnterMaterial: function (oEvent) {
			this._onValidarMaterialTable(oEvent);

		},
		_onValidarMaterialTable: function (oEt) {

			var la_filtersOr = [];
			var la_filtersAnd = [];
			var lo_paraFilter = [];

			var sMaterial = oEt.getParameters().value;

			if (sMaterial != "") {
				lo_paraFilter.push(new sap.ui.model.Filter({
					path: "material",
					operator: sap.ui.model.FilterOperator.EQ,
					value1: sMaterial
				}));

			}
			this.sPath = oEt.getSource().getParent().getBindingContextPath("MPedido");



			la_filtersAnd.push(new sap.ui.model.Filter(lo_paraFilter, true));

			this.getModel().read("/datosMaterialSet", {
				filters: la_filtersAnd,
				success: function (oData, response) {
					this._onMostrarMensaje("msgMaterial");
					var oModelDetalle = this.getOwnerComponent().getModel("MPedido");
					if (oData.results.length != 0) {
						oModelDetalle.setProperty(this.sPath + "/descripcion", oData.results[0].descripcion);
					}
				}.bind(this),
				error: function (error) {
					this._onMostrarMensaje("msgNoMaterial");
					var hdrMessageObject = JSON.parse(error.responseText);
					MessageToast.show(hdrMessageObject.error.message.value);
				}.bind(this)
			});
		}

	});

});