sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter"
], function(BaseController, JSONModel, MessageToast, MessageBox, Dialog, Button, History, Filter) {
	"use strict";

	return BaseController.extend("gest.adic.cirugia.controller.inicio", {
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;

		    this.getView().byId("idPage").setBusy(true);
			var oModel = this.getOwnerComponent().getModel();
			oModel.metadataLoaded(true).then(function() {
				that.oView.byId("idPage").setBusy(false);
			}, this);

			oRouter.getRoute("inicio").attachMatched(this._onRouteFound, this);

		},
		_onRouteFound: function(oEvent) {
			this.getView().byId("idsala").focus();
		},
		_onButtonPressSearch: function(oEvent) {

			this._onBuscarPedido();

		},

		_onBuscarPedido: function() {

			var onSucess = jQuery.proxy(this.onSuccessEtiqueta, this);
			var onError = jQuery.proxy(this.onError, this);

			var la_filtersOr = [];
			var la_filtersAnd = [];
			var lo_paraFilter = [];

			let vsala = this.getView().byId("idsala").getValue();
			let vpaciente = this.getView().byId("idpaciente").getValue();
			let vdocumento = this.getView().byId("iddocumento").getValue();
			let vprotocolo = this.getView().byId("idprotocolo").getValue();
			let vsaleeme = this.getView().byId("idsaleeme").getValue();
			let vprotoeme = this.getView().byId("idprotoeme").getValue();


			
			if (vdocumento != "") {

				if (vsala != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "sala_cirugia",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("idsala").getValue()
					}));

				}
				if (vpaciente != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "nombre_paciente",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("idpaciente").getValue()
					}));
				}
				if (vdocumento != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "doc_pacienteId",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("iddocumento").getValue()
					}));
				}
				if (vprotocolo != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "protocolo_cirugia",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("idprotocolo").getSelectedKey()
					}));
				}
				if (vsaleeme != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "sala_urgencia",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("idsaleeme").getValue()
					}));
				}
				if (vprotoeme != "") {
					lo_paraFilter.push(new sap.ui.model.Filter({
						path: "protocolo_urgencia",
						operator: sap.ui.model.FilterOperator.EQ,
						value1: this.getView().byId("idprotoeme").getSelectedKey()
					}));
				}

			
				la_filtersAnd.push(new sap.ui.model.Filter( lo_paraFilter, true));

				this.getModel().read("/update_pedidoSet", {
					filters: la_filtersAnd,
					success: function(oData, response) {
						var oNameModel = 'MPedido';
			
						onSucess(oData, response, oNameModel, this);

					}.bind(this),
					error: function(error) {
						onError(error);
					}.bind(this)
				});
		} else {
			MessageToast.show('Por favor llene el campo Doc Paciente'); 
		}
		},
		onError: function(error) {
				var hdrMessageObject = JSON.parse(error.responseText);
			

		 
				MessageToast.show(hdrMessageObject.error.message.value); 

		},

		/**
		 * Carga el modelo "pedido"  con los datos recuperados del get
		 *
		 * @param  {thas} Instancia de la vista (Detalle)
		 */
		onSuccessEtiqueta: function(oData, response, oNameModel, thas) {
			var modelo = [];
			var oModeloJson = new JSONModel();
			var existeEtiqueta;

		 

				if (oData.results) {

					if (oData.results.length === 0) {
						this._onMostrarMensaje("msgPedido");

					} else {

						for (var i = 0; i < oData.results.length; i++) {
							modelo.push(oData.results[i]);

						}

						oModeloJson.setData(modelo);
					}

					// se colocan los modelos para que sea visible para las demas vistas
					this.getOwnerComponent().setModel(oModeloJson, oNameModel);
				
			}

			var nparameter = {
				"sala_cirugia": "sala",
				"nombre_paciente": "nombre_paciente"
			};
			this.getRouter().navTo("detalle", {
				data: JSON.stringify(nparameter)
			}, true);
		},
		_onMostrarMensaje: function(text, key) {
			var propiedadesmensjae = {
				duration: 3000, // default
				width: "40em", // default
				my: "center top", // default
				at: "center top", // default
				// of: this.getView().byId("idlistado"), // default
				offset: "0 0", // default
				collision: "fit fit", // default
				onClose: null, // default
				autoClose: false, // default
				animationTimingFunction: "ease-in-out", // default
				animationDuration: 1000, // default
				closeOnBrowserNavigation: false // default
			};

			var mensaje = this.getResourceBundle().getText(text, [key]);
			MessageToast.show(mensaje, propiedadesmensjae);

		},
		onAfterRendering: function() {

			this.getView().byId("idsala").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("idsala").setBusy(false);
			}.bind(this));

			this.getView().byId("idpaciente").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("idpaciente").setBusy(false);
			}.bind(this));

			this.getView().byId("iddocumento").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("iddocumento").setBusy(false);
			}.bind(this));

			this.getView().byId("idprotocolo").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("idprotocolo").setBusy(false);
			}.bind(this));

			this.getView().byId("idsaleeme").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("idsaleeme").setBusy(false);
			}.bind(this));

			this.getView().byId("idprotoeme").getBinding("items").attachDataReceived(function(oEvent) {
				this.getView().byId("idprotoeme").setBusy(false);
			}.bind(this));

		}

	});
});